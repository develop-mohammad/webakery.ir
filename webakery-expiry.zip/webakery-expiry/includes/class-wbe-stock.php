<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کاهش/بازگشت موجودی سفارش و فیلتر قیمت فعال (با تخفیف بچ).
 */
class WBE_Stock {

	public static function register() {
		add_action( 'woocommerce_reduce_order_stock', array( __CLASS__, 'on_reduce' ) );
		add_action( 'woocommerce_restore_order_stock', array( __CLASS__, 'on_restore' ) );
		add_filter( 'woocommerce_product_get_price', array( __CLASS__, 'filter_price' ), 99, 2 );
		add_filter( 'woocommerce_product_get_regular_price', array( __CLASS__, 'filter_regular_price' ), 99, 2 );
		add_filter( 'woocommerce_product_get_sale_price', array( __CLASS__, 'filter_sale_price' ), 99, 2 );
		add_filter( 'woocommerce_product_get_stock_quantity', array( __CLASS__, 'filter_stock' ), 99, 2 );
		add_filter( 'woocommerce_product_is_on_sale', array( __CLASS__, 'filter_on_sale' ), 99, 2 );
		add_filter( 'woocommerce_product_variation_get_price', array( __CLASS__, 'filter_price' ), 99, 2 );
		add_filter( 'woocommerce_product_variation_get_regular_price', array( __CLASS__, 'filter_regular_price' ), 99, 2 );
		add_filter( 'woocommerce_product_variation_get_sale_price', array( __CLASS__, 'filter_sale_price' ), 99, 2 );
		add_filter( 'woocommerce_product_variation_get_stock_quantity', array( __CLASS__, 'filter_stock' ), 99, 2 );
		add_filter( 'woocommerce_variation_is_on_sale', array( __CLASS__, 'filter_on_sale' ), 99, 2 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_sync_viewed' ) );
	}

	public static function on_reduce( $order ) {
		if ( ! WBE_Plugin::licensed() || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}
		foreach ( $order->get_items() as $item ) {
			if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				continue;
			}
			$pid = self::item_stock_id( $item );
			if ( ! $pid || ! WBE_Product::configured( $pid ) ) {
				continue;
			}
			$qty      = (int) $item->get_quantity();
			$batch_id = WBE_Product::consume( $pid, $qty );
			if ( $batch_id ) {
				$item->add_meta_data( '_wbe_batch_id', $batch_id, true );
				$item->save();
			}
		}
	}

	public static function on_restore( $order ) {
		if ( ! WBE_Plugin::licensed() || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}
		foreach ( $order->get_items() as $item ) {
			if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				continue;
			}
			$pid = self::item_stock_id( $item );
			if ( ! $pid || ! WBE_Product::configured( $pid ) ) {
				continue;
			}
			$batch_id = (string) $item->get_meta( '_wbe_batch_id' );
			WBE_Product::restore( $pid, (int) $item->get_quantity(), $batch_id );
		}
	}

	/**
	 * برای تنوع، شناسه variation؛ وگرنه شناسه محصول.
	 *
	 * @param WC_Order_Item_Product $item
	 * @return int
	 */
	public static function item_stock_id( $item ) {
		if ( ! is_object( $item ) ) {
			return 0;
		}
		$vid = method_exists( $item, 'get_variation_id' ) ? (int) $item->get_variation_id() : 0;
		$pid = method_exists( $item, 'get_product_id' ) ? (int) $item->get_product_id() : 0;
		return (int) WBE_Engine::order_item_stock_id( $pid, $vid );
	}

	public static function filter_regular_price( $price, $product ) {
		if ( WBE_Product::is_syncing() || ! self::ok_product( $product ) ) {
			return $price;
		}
		$active = WBE_Product::active( $product->get_id() );
		return $active ? (string) $active['price'] : $price;
	}

	public static function filter_sale_price( $price, $product ) {
		if ( WBE_Product::is_syncing() || ! self::ok_product( $product ) ) {
			return $price;
		}
		$active = WBE_Product::active( $product->get_id() );
		if ( ! self::discount_live( $product, $active ) ) {
			return '';
		}
		return (string) WBE_Engine::effective_sale( $active );
	}

	public static function filter_price( $price, $product ) {
		if ( WBE_Product::is_syncing() || ! self::ok_product( $product ) ) {
			return $price;
		}
		$active = WBE_Product::active( $product->get_id() );
		if ( ! $active ) {
			return $price;
		}
		if ( ! self::discount_live( $product, $active ) ) {
			return (string) $active['price'];
		}
		return (string) WBE_Engine::effective_sale( $active );
	}

	/**
	 * موجودی فروشگاه = موجودی ووکامرس (ساده و تنوع). بچ فقط رزرو/انقضا را نگه می‌دارد.
	 *
	 * @param mixed      $qty
	 * @param WC_Product $product
	 * @return mixed
	 */
	public static function filter_stock( $qty, $product ) {
		unset( $product );
		return $qty;
	}

	public static function filter_on_sale( $on_sale, $product ) {
		if ( ! self::ok_product( $product ) ) {
			return $on_sale;
		}
		$active = WBE_Product::active( $product->get_id() );
		return self::discount_live( $product, $active );
	}

	/**
	 * تخفیف بچ فقط در بازه فروش فوق‌العاده (اگر تاریخ از/تا ست شده باشد).
	 *
	 * @param WC_Product $product
	 * @param array|null $active
	 * @return bool
	 */
	public static function discount_live( $product, $active ) {
		if ( ! is_array( $active ) || WBE_Engine::discount_of( $active ) <= 0 ) {
			return false;
		}
		$today = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::today_ymd() : gmdate( 'Y-m-d' );
		$pair  = WBE_Product::sale_ymd_pair( $product );
		$from  = $pair[0];
		$to    = $pair[1] !== '' ? $pair[1] : ( isset( $active['expiry'] ) ? (string) $active['expiry'] : '' );
		return WBE_Engine::sale_window_live( $from, $to, $today );
	}

	public static function maybe_sync_viewed() {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}
		$id = get_queried_object_id();
		if ( ! $id || ! WBE_Plugin::licensed() ) {
			return;
		}
		if ( WBE_Product::configured( $id ) ) {
			WBE_Product::sync_wc( $id );
			return;
		}
		// محصول متغیر: بچ‌ها روی تنوع‌ها هستند.
		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $id );
			if ( $product && method_exists( $product, 'is_type' ) && $product->is_type( 'variable' ) && method_exists( $product, 'get_children' ) ) {
				foreach ( $product->get_children() as $vid ) {
					if ( WBE_Product::configured( (int) $vid ) ) {
						WBE_Product::sync_wc( (int) $vid );
					}
				}
			}
		}
	}

	private static function ok_product( $product ) {
		if ( ! WBE_Plugin::licensed() || ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return false;
		}
		// والد متغیر قیمت/موجودی خودش ندارد.
		if ( method_exists( $product, 'is_type' ) && $product->is_type( 'variable' ) ) {
			return false;
		}
		return WBE_Product::configured( $product->get_id() );
	}
}
