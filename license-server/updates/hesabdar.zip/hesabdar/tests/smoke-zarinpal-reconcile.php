<?php
/**
 * Smoke tests for Zarinpal reconcile notify helpers (no live API).
 */
error_reporting( E_ALL );
define( 'ABSPATH', '/' );

$GLOBALS['wap_opt'] = array();
$GLOBALS['wap_sms_sent'] = array();

function get_option( $k, $d = false ) {
	return array_key_exists( $k, $GLOBALS['wap_opt'] ) ? $GLOBALS['wap_opt'][ $k ] : $d;
}
function update_option( $k, $v, $a = false ) {
	$GLOBALS['wap_opt'][ $k ] = $v;
	return true;
}
function current_time( $t ) {
	return '2026-09-05 12:00:00';
}
function wp_json_encode( $d ) {
	return json_encode( $d );
}
function is_wp_error( $t ) {
	return $t instanceof WP_Error;
}
function add_action( $a, $b, $c = 10 ) {}
function wp_next_scheduled( $h ) {
	return false;
}
function wp_schedule_event( $t, $r, $h ) {}
function wp_unschedule_event( $t, $h ) {}
function wp_remote_post( $u, $a ) {
	return array( 'response' => array( 'code' => 200 ), 'body' => '' );
}
function wp_remote_retrieve_response_code( $r ) {
	return 200;
}
function wp_remote_retrieve_body( $r ) {
	return '{"data":{"resource":[]}}';
}

class WP_Error {
	private $m;
	public function __construct( $c, $m ) {
		$this->m = $m;
	}
	public function get_error_message() {
		return $this->m;
	}
}

class WAP_SMS {
	public static $cfg = array(
		'settle_enabled'  => 1,
		'zp_access_token' => 'tok',
		'zp_terminal_id'  => '123',
		'settle_message'  => 'واریز {amount} ریف {reference_id}',
	);
	public static function get( $k = null, $d = null ) {
		return $k === null ? self::$cfg : ( self::$cfg[ $k ] ?? $d );
	}
	public static function recipient_list() {
		return array( '09121234567' );
	}
	public static function send( $p, $m ) {
		$GLOBALS['wap_sms_sent'][] = array( $p, $m );
		return true;
	}
}

require dirname( __DIR__ ) . '/includes/class-wap-zarinpal-reconcile.php';

// Monkey-patch fetch via subclass-style override: temporarily replace by wrapping poll
// Use reflection-free approach: call poll with mocked fetch by subclassing isn't easy;
// instead test seed by injecting notified empty and stubbing fetch_reconciles via runkit-less copy.

class WAP_Zarinpal_Reconcile_Test extends WAP_Zarinpal_Reconcile {
	public static $rows = array();
	public static function fetch_reconciles( string $token, string $terminal_id ) {
		return self::$rows;
	}
}

// First run seeds without SMS
WAP_Zarinpal_Reconcile_Test::$rows = array(
	array(
		'id'            => 'r1',
		'status'        => 'PAID',
		'amount'        => 100000,
		'reference_id'  => 'REF1',
		'reconciled_at' => '2026-09-01',
	),
	array(
		'id'            => 'r2',
		'status'        => 'PENDING',
		'amount'        => 50000,
		'reference_id'  => 'REF2',
		'reconciled_at' => '2026-09-02',
	),
);
$GLOBALS['wap_opt'] = array();
$GLOBALS['wap_sms_sent'] = array();
$msg = WAP_Zarinpal_Reconcile_Test::poll_and_notify( true );
assert( is_string( $msg ), 'seed should return string' );
assert( strpos( $msg, 'اولین بررسی' ) !== false, 'seed message' );
assert( count( $GLOBALS['wap_sms_sent'] ) === 0, 'no SMS on seed' );
assert( isset( $GLOBALS['wap_opt'][ WAP_Zarinpal_Reconcile::NOTIFIED_OPT ]['r1'] ), 'r1 seeded' );
assert( ! isset( $GLOBALS['wap_opt'][ WAP_Zarinpal_Reconcile::NOTIFIED_OPT ]['r2'] ), 'pending not seeded' );

// Second run with new PAID sends SMS
WAP_Zarinpal_Reconcile_Test::$rows[] = array(
	'id'            => 'r3',
	'status'        => 'PAID',
	'amount'        => 200000,
	'reference_id'  => 'REF3',
	'reconciled_at' => '2026-09-05',
);
$msg2 = WAP_Zarinpal_Reconcile_Test::poll_and_notify( true );
assert( is_string( $msg2 ), 'second poll string' );
assert( strpos( $msg2, '1 پیامک' ) !== false || strpos( $msg2, '۱' ) !== false || preg_match( '/1 پیامک/', $msg2 ), 'one SMS: ' . $msg2 );
assert( count( $GLOBALS['wap_sms_sent'] ) === 1, 'one SMS sent' );
assert( strpos( $GLOBALS['wap_sms_sent'][0][1], 'REF3' ) !== false, 'message has ref' );
assert( isset( $GLOBALS['wap_opt'][ WAP_Zarinpal_Reconcile::NOTIFIED_OPT ]['r3'] ), 'r3 notified' );

echo "ALL ZARINPAL RECONCILE SMOKE TESTS PASSED\n";
