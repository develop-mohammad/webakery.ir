<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * منطق بچ‌ها — بدون وابستگی به وردپرس/ووکامرس.
 *
 * ترتیب فعال: نزدیک‌ترین انقضای معتبر؛ اگر برابر بود، ترتیب ورود ادمین.
 * نامعتبر = موجودی صفر یا تاریخ گذشته.
 */
class WBE_Engine {

	/**
	 * طبقه‌بندی‌های رایج برند ووکامرس.
	 * اولویت با ویژگی‌های محصول (pa_*) است تا برند تکراری از چند منبع نیاید.
	 *
	 * @return array<int,string>
	 */
	public static function brand_taxonomy_slugs() {
		return array( 'pa_brand', 'pa_brands', 'product_brand', 'pwb-brand', 'product_brands' );
	}

	/**
	 * آیا نام/برچسب شبیه «برند» است؟
	 *
	 * @param string $name
	 * @param string $label
	 * @return bool
	 */
	public static function looks_like_brand( $name, $label = '' ) {
		$hay = strtolower( trim( (string) $name . ' ' . (string) $label ) );
		if ( $hay === '' ) {
			return false;
		}
		if ( false !== strpos( $hay, 'brand' ) ) {
			return true;
		}
		if ( function_exists( 'mb_stripos' ) ) {
			return false !== mb_stripos( (string) $name . (string) $label, 'برند' );
		}
		return false !== stripos( (string) $name . (string) $label, 'برند' );
	}

	/**
	 * موجودی رزرو = جمع موجودی بچ‌هایی که الان فعال نیستند.
	 *
	 * @param array  $batches
	 * @param string $today
	 * @return int
	 */
	/**
	 * فهرست بچ‌های رزرو (غیر فعال) به‌ترتیب.
	 *
	 * @param array  $batches
	 * @param string $today
	 * @return array<int,array>
	 */
	public static function reserve_batches( array $batches, $today ) {
		$active = self::active_index( $batches, $today );
		$out    = array();
		foreach ( $batches as $i => $batch ) {
			if ( null !== $active && (int) $i === (int) $active ) {
				continue;
			}
			$out[] = $batch;
		}
		return $out;
	}

	/**
	 * جایگزینی همهٔ بچ‌های رزرو با فهرست جدید؛ بچ فعال حفظ می‌شود.
	 *
	 * @param array  $batches
	 * @param array  $reserve_rows ردیف‌های خام رزرو
	 * @param string $today
	 * @param string $calendar
	 * @return array
	 */
	public static function replace_reserve_batches( array $batches, array $reserve_rows, $today, $calendar = 'gregorian' ) {
		$active_idx = self::active_index( $batches, $today );
		$out        = array();
		if ( null !== $active_idx && isset( $batches[ $active_idx ] ) ) {
			$out[] = $batches[ $active_idx ];
		}
		$san = self::sanitize_batches( $reserve_rows, $calendar );
		foreach ( $san as $row ) {
			$out[] = $row;
		}
		return $out;
	}

	/**
	 * ایندکس اولین بچ رزرو (غیر فعال).
	 *
	 * @param array  $batches
	 * @param string $today
	 * @return int|null
	 */
	public static function primary_reserve_index( array $batches, $today ) {
		$active = self::active_index( $batches, $today );
		foreach ( $batches as $i => $_b ) {
			if ( null !== $active && (int) $i === (int) $active ) {
				continue;
			}
			return (int) $i;
		}
		return null;
	}

	/**
	 * اعمال ویرایش روی بچ رزرو اصلی (قیمت / تخفیف / موجودی / انقضا).
	 * اگر رزرو نباشد و انقضا+موجودی آمده باشد، بچ رزرو جدید ساخته می‌شود.
	 *
	 * @param array  $batches
	 * @param array  $ops      res_price, res_discount, res_stock, res_expiry, calendar
	 * @param string $today
	 * @return array
	 */
	public static function apply_bulk_to_reserve( array $batches, array $ops, $today ) {
		$has = array_key_exists( 'res_price', $ops )
			|| array_key_exists( 'res_discount', $ops )
			|| array_key_exists( 'res_stock', $ops )
			|| ! empty( $ops['res_expiry'] );
		if ( ! $has ) {
			return $batches;
		}

		$idx = self::primary_reserve_index( $batches, $today );
		if ( null === $idx ) {
			$cal   = isset( $ops['calendar'] ) ? (string) $ops['calendar'] : 'gregorian';
			$row   = array(
				'price'    => array_key_exists( 'res_price', $ops ) ? $ops['res_price'] : 0,
				'discount' => array_key_exists( 'res_discount', $ops ) ? $ops['res_discount'] : 0,
				'stock'    => array_key_exists( 'res_stock', $ops ) ? $ops['res_stock'] : 0,
				'expiry'   => ! empty( $ops['res_expiry'] ) ? $ops['res_expiry'] : '',
			);
			if ( '' === (string) $row['expiry'] ) {
				return $batches;
			}
			return self::append_batch( $batches, $row, $cal );
		}

		$b = $batches[ $idx ];
		if ( array_key_exists( 'res_price', $ops ) && null !== $ops['res_price'] && '' !== $ops['res_price'] ) {
			$b['price'] = (string) max( 0, (float) $ops['res_price'] );
		}
		if ( array_key_exists( 'res_discount', $ops ) && null !== $ops['res_discount'] && '' !== $ops['res_discount'] ) {
			$disc           = max( 0, min( 100, (float) $ops['res_discount'] ) );
			$b['discount']  = (int) round( $disc );
			$price          = isset( $b['price'] ) ? (float) $b['price'] : 0;
			if ( $price > 0 && $disc > 0 ) {
				$b['sale'] = (string) self::sale_price( $price, $disc );
			} else {
				unset( $b['sale'] );
			}
		}
		if ( array_key_exists( 'res_stock', $ops ) && null !== $ops['res_stock'] && '' !== $ops['res_stock'] ) {
			$b['stock'] = max( 0, (int) $ops['res_stock'] );
		}
		if ( ! empty( $ops['res_expiry'] ) ) {
			$b['expiry'] = (string) $ops['res_expiry'];
		}
		$batches[ $idx ] = $b;
		return $batches;
	}

	public static function reserved_stock( array $batches, $today ) {
		$active = self::active_index( $batches, $today );
		$sum    = 0;
		foreach ( $batches as $i => $batch ) {
			if ( null !== $active && (int) $i === (int) $active ) {
				continue;
			}
			$sum += isset( $batch['stock'] ) ? max( 0, (int) $batch['stock'] ) : 0;
		}
		return $sum;
	}

	/**
	 * تنظیم جمع موجودی رزرو روی بچ‌های غیر فعال.
	 * اگر چند بچ رزرو باشد، کل مقدار روی اولین رزرو می‌نشیند و بقیه صفر می‌شوند.
	 *
	 * @param array  $batches
	 * @param int    $qty
	 * @param string $today
	 * @return array
	 */
	public static function set_reserved_stock( array $batches, $qty, $today ) {
		$qty         = max( 0, (int) $qty );
		$active      = self::active_index( $batches, $today );
		$reserve_idx = array();
		foreach ( $batches as $i => $_b ) {
			if ( null !== $active && (int) $i === (int) $active ) {
				continue;
			}
			$reserve_idx[] = (int) $i;
		}
		if ( ! $reserve_idx ) {
			return $batches;
		}
		$first = true;
		foreach ( $reserve_idx as $i ) {
			$batches[ $i ]['stock'] = $first ? $qty : 0;
			$first                  = false;
		}
		return $batches;
	}

	/**
	 * قیمت جشنوارهٔ واقعی بچ: اگر مبلغ دستی ذخیره شده باشد همان، وگرنه از درصد.
	 *
	 * @param array $batch
	 * @return float
	 */
	public static function effective_sale( $batch ) {
		if ( ! is_array( $batch ) ) {
			return 0.0;
		}
		$regular = isset( $batch['price'] ) ? (float) $batch['price'] : 0.0;
		if ( $regular <= 0 ) {
			return 0.0;
		}
		if ( isset( $batch['sale'] ) && '' !== $batch['sale'] && is_numeric( $batch['sale'] ) ) {
			$sale = (float) $batch['sale'];
			if ( $sale > 0 && $sale < $regular ) {
				return $sale;
			}
		}
		$disc = self::discount_of( $batch );
		if ( $disc <= 0 ) {
			return $regular;
		}
		return self::sale_price( $regular, $disc );
	}

	/**
	 * افزودن یک بچ رزرو جدید به انتهای فهرست.
	 *
	 * @param array  $batches
	 * @param array  $row      price/stock/expiry/discount/sale
	 * @param string $calendar
	 * @return array
	 */
	public static function append_batch( array $batches, array $row, $calendar = 'gregorian' ) {
		$san = self::sanitize_batches( array( $row ), $calendar );
		if ( ! $san ) {
			return $batches;
		}
		return array_merge( $batches, $san );
	}

	/**
	 * آیا متن فیلتر داخل برچسب هست؟
	 *
	 * @param string $haystack
	 * @param string $needle
	 * @return bool
	 */
	public static function text_has( $haystack, $needle ) {
		$haystack = (string) $haystack;
		$needle   = (string) $needle;
		if ( $needle === '' ) {
			return true;
		}
		if ( function_exists( 'mb_stripos' ) ) {
			return false !== mb_stripos( $haystack, $needle );
		}
		return false !== stripos( $haystack, $needle );
	}

	/**
	 * @param array  $batches
	 * @param string $today Y-m-d
	 * @return int|null
	 */
	public static function active_index( array $batches, $today ) {
		$best_i = null;
		$best_e = null;
		foreach ( $batches as $i => $batch ) {
			if ( ! self::is_valid( $batch, $today ) ) {
				continue;
			}
			$exp = (string) $batch['expiry'];
			if ( null === $best_i || $exp < $best_e ) {
				$best_i = (int) $i;
				$best_e = $exp;
			}
		}
		return $best_i;
	}

	/**
	 * @param array  $batch
	 * @param string $today Y-m-d
	 * @return bool
	 */
	public static function is_valid( $batch, $today ) {
		if ( ! is_array( $batch ) ) {
			return false;
		}
		$stock = isset( $batch['stock'] ) ? (int) $batch['stock'] : 0;
		$exp   = isset( $batch['expiry'] ) ? (string) $batch['expiry'] : '';
		if ( $stock <= 0 || $exp === '' ) {
			return false;
		}
		return $exp >= (string) $today;
	}

	/**
	 * کاهش موجودی بچ فعال. اگر صفر شد، حلقه در خواندن بعدی سراغ رزرو می‌رود.
	 *
	 * @param array  $batches
	 * @param int    $qty
	 * @param string $today
	 * @return array{batches:array,batch_id:string,consumed:int}
	 */
	public static function consume( array $batches, $qty, $today ) {
		$qty      = max( 0, (int) $qty );
		$consumed = 0;
		$batch_id = '';
		$idx      = self::active_index( $batches, $today );
		if ( null === $idx || $qty <= 0 ) {
			return array(
				'batches'  => $batches,
				'batch_id' => $batch_id,
				'consumed' => 0,
			);
		}
		$have = (int) $batches[ $idx ]['stock'];
		$take = min( $qty, $have );
		$batches[ $idx ]['stock'] = $have - $take;
		$consumed = $take;
		$batch_id = isset( $batches[ $idx ]['id'] ) ? (string) $batches[ $idx ]['id'] : '';
		return array(
			'batches'  => $batches,
			'batch_id' => $batch_id,
			'consumed' => $consumed,
		);
	}

	/**
	 * @param array  $batches
	 * @param int    $qty
	 * @param string $batch_id
	 * @return array
	 */
	public static function restore( array $batches, $qty, $batch_id ) {
		$qty = max( 0, (int) $qty );
		if ( $qty <= 0 ) {
			return $batches;
		}
		foreach ( $batches as $i => $batch ) {
			if ( isset( $batch['id'] ) && (string) $batch['id'] === (string) $batch_id ) {
				$batches[ $i ]['stock'] = (int) $batch['stock'] + $qty;
				return $batches;
			}
		}
		return $batches;
	}

	/**
	 * @param mixed  $rows
	 * @param string $calendar jalali|gregorian
	 * @return array
	 */
	public static function sanitize_batches( $rows, $calendar = 'gregorian' ) {
		$out = array();
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		$n = 0;
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$price  = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::number( isset( $row['price'] ) ? $row['price'] : 0 ) : (float) $row['price'];
			$stock  = (int) ( class_exists( 'WBE_Jalali' ) ? WBE_Jalali::number( isset( $row['stock'] ) ? $row['stock'] : 0 ) : $row['stock'] );
			$expiry = '';
			if ( class_exists( 'WBE_Jalali' ) ) {
				$expiry = WBE_Jalali::parse_to_ymd( isset( $row['expiry'] ) ? $row['expiry'] : '', $calendar );
			} else {
				$expiry = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $row['expiry'] ) ? (string) $row['expiry'] : '';
			}
			if ( $expiry === '' && $price <= 0 && $stock <= 0 ) {
				continue;
			}
			if ( $expiry === '' ) {
				continue;
			}
			$discount = isset( $row['discount'] ) ? (string) $row['discount'] : '0';
			if ( class_exists( 'WBE_Jalali' ) ) {
				$discount = WBE_Jalali::fa_to_en( $discount );
			}
			$discount = str_replace( array( '%', '٪', ',', '٬', '،', ' ' ), '', $discount );
			$discount = is_numeric( $discount ) ? (float) $discount : 0;
			$discount = (int) round( max( 0, min( 100, $discount ) ) );
			$id       = isset( $row['id'] ) ? preg_replace( '/[^a-zA-Z0-9_\-]/', '', (string) $row['id'] ) : '';
			if ( $id === '' ) {
				$id = 'b' . sprintf( '%04d', $n ) . substr( md5( $expiry . '|' . $price . '|' . $n ), 0, 8 );
			}
			$item = array(
				'id'       => $id,
				'price'    => (string) $price,
				'discount' => $discount,
				'stock'    => max( 0, $stock ),
				'expiry'   => $expiry,
			);
			// مبلغ جشنوارهٔ دستی (اختیاری) — تا با رند درصد از بین نرود.
			if ( isset( $row['sale'] ) && '' !== $row['sale'] && null !== $row['sale'] ) {
				$sale = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::number( $row['sale'] ) : (float) $row['sale'];
				if ( $sale > 0 && $sale < $price ) {
					$item['sale'] = (string) $sale;
					if ( $discount <= 0 ) {
						$item['discount'] = self::discount_from_prices( $price, $sale );
					}
				}
			}
			$out[] = $item;
			$n++;
		}
		return $out;
	}

	/**
	 * محصول «تنظیم‌شده» است اگر حداقل یک بچ ثبت شده باشد.
	 *
	 * @param array $batches
	 * @return bool
	 */
	public static function is_configured( array $batches ) {
		return ! empty( $batches );
	}

	/**
	 * تایمر کمپین: تنظیمات سراسری روشن باشد و روی محصول مخفی نشده باشد.
	 *
	 * @param mixed $global_on
	 * @param mixed $product_hidden
	 * @return bool
	 */
	public static function countdown_allowed( $global_on, $product_hidden ) {
		if ( empty( $global_on ) || '0' === (string) $global_on ) {
			return false;
		}
		if ( ! empty( $product_hidden ) && '0' !== (string) $product_hidden ) {
			return false;
		}
		return true;
	}

	/**
	 * درصد تخفیف بچ (۰ تا ۱۰۰).
	 *
	 * @param array $batch
	 * @return int
	 */
	public static function discount_of( $batch ) {
		if ( ! is_array( $batch ) ) {
			return 0;
		}
		return max( 0, min( 100, (int) round( isset( $batch['discount'] ) ? (float) $batch['discount'] : 0 ) ) );
	}

	/**
	 * قیمت پس از تخفیف. بدون تخفیف همان قیمت اصلی است.
	 *
	 * @param float|string $price
	 * @param float|int    $discount
	 * @return float
	 */
	public static function sale_price( $price, $discount ) {
		$price    = (float) $price;
		$discount = max( 0, min( 100, (float) $discount ) );
		if ( $discount <= 0 ) {
			return $price;
		}
		return (float) round( $price * ( 100 - $discount ) / 100 );
	}

	/**
	 * آیا امروز داخل بازه فروش فوق‌العاده است؟ تاریخ خالی = بدون محدودیت.
	 *
	 * @param string $from_ymd Y-m-d یا خالی
	 * @param string $to_ymd   Y-m-d یا خالی
	 * @param string $today    Y-m-d
	 * @return bool
	 */
	public static function sale_window_live( $from_ymd, $to_ymd, $today ) {
		$today = (string) $today;
		$from  = (string) $from_ymd;
		$to    = (string) $to_ymd;
		if ( $from !== '' && $from > $today ) {
			return false;
		}
		if ( $to !== '' && $to < $today ) {
			return false;
		}
		return true;
	}

	/**
	 * متن بازه فروش فوق‌العاده برای مشتری.
	 *
	 * @param string $from_ymd
	 * @param string $to_ymd
	 * @param string $calendar jalali|gregorian
	 * @param bool   $fa_digits
	 * @return string
	 */
	public static function sale_dates_text( $from_ymd, $to_ymd, $calendar = 'jalali', $fa_digits = true ) {
		$from_f = ( $from_ymd !== '' && class_exists( 'WBE_Jalali' ) ) ? WBE_Jalali::format_ymd( $from_ymd, $calendar, $fa_digits ) : '';
		$to_f   = ( $to_ymd !== '' && class_exists( 'WBE_Jalali' ) ) ? WBE_Jalali::format_ymd( $to_ymd, $calendar, $fa_digits ) : '';
		if ( $from_f && $to_f ) {
			return 'از ' . $from_f . ' تا ' . $to_f;
		}
		if ( $to_f ) {
			return 'تا ' . $to_f;
		}
		if ( $from_f ) {
			return 'از ' . $from_f;
		}
		return '';
	}

	/**
	 * پایان روز Y-m-d به timestamp یونیکس (منطقه زمانی سایت).
	 *
	 * @param string $ymd
	 * @return int
	 */
	public static function ymd_end_ts( $ymd ) {
		$ymd = (string) $ymd;
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $ymd ) ) {
			return 0;
		}
		if ( function_exists( 'wp_timezone' ) ) {
			$dt = date_create( $ymd . ' 23:59:59', wp_timezone() );
			return $dt ? $dt->getTimestamp() : 0;
		}
		$ts = strtotime( $ymd . ' 23:59:59' );
		return $ts ? (int) $ts : 0;
	}

	/**
	 * قطعات تایمر معکوس.
	 *
	 * @param int $end_ts
	 * @param int $now_ts
	 * @return array{remaining:int,days:int,hours:int,minutes:int,seconds:int}
	 */
	public static function countdown_parts( $end_ts, $now_ts ) {
		$left = max( 0, (int) $end_ts - (int) $now_ts );
		return array(
			'remaining' => $left,
			'days'      => (int) floor( $left / 86400 ),
			'hours'     => (int) floor( ( $left % 86400 ) / 3600 ),
			'minutes'   => (int) floor( ( $left % 3600 ) / 60 ),
			'seconds'   => (int) ( $left % 60 ),
		);
	}

	/**
	 * درصد تخفیف از قیمت اصلی و قیمت فروش ووکامرس.
	 *
	 * @param float|string     $regular
	 * @param float|string|null $sale
	 * @return int
	 */
	public static function discount_from_prices( $regular, $sale ) {
		$regular = (float) $regular;
		if ( $sale === null || $sale === '' || ! is_numeric( $sale ) ) {
			return 0;
		}
		$sale = (float) $sale;
		if ( $regular <= 0 || $sale < 0 || $sale >= $regular ) {
			return 0;
		}
		return max( 0, min( 100, (int) round( 100 - ( ( $sale / $regular ) * 100 ) ) ) );
	}

	/**
	 * قیمت ووکامرس را روی بچ فعال می‌نویسد (تغییر گروهی / محصول تازه).
	 * اگر بچ فعال نباشد، اولین ردیف به‌روز می‌شود.
	 *
	 * @param array            $batches
	 * @param float|string     $regular
	 * @param float|string|null $sale
	 * @param string           $today
	 * @param bool             $update_discount اگر false باشد درصد تخفیف قبلی می‌ماند
	 * @return array
	 */
	public static function apply_wc_price_to_active( array $batches, $regular, $sale, $today, $update_discount = true ) {
		if ( empty( $batches ) ) {
			return $batches;
		}
		$regular = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::number( $regular ) : (float) $regular;
		if ( $regular <= 0 ) {
			return $batches;
		}
		$idx = self::active_index( $batches, $today );
		if ( null === $idx ) {
			$keys = array_keys( $batches );
			$idx  = (int) $keys[0];
		}
		if ( ! isset( $batches[ $idx ] ) || ! is_array( $batches[ $idx ] ) ) {
			return $batches;
		}
		$same_price = (string) (float) $batches[ $idx ]['price'] === (string) (float) $regular;
		if ( $update_discount ) {
			$discount = self::discount_from_prices( $regular, $sale );
			if ( $same_price && (int) self::discount_of( $batches[ $idx ] ) === $discount ) {
				$has_manual = isset( $batches[ $idx ]['sale'] ) && '' !== $batches[ $idx ]['sale'];
				$want_manual = ( $sale !== null && $sale !== '' && is_numeric( $sale ) && (float) $sale > 0 && (float) $sale < (float) $regular );
				if ( $has_manual === $want_manual && ( ! $want_manual || (string) (float) $batches[ $idx ]['sale'] === (string) (float) $sale ) ) {
					return $batches;
				}
			}
			$batches[ $idx ]['discount'] = $discount;
			if ( $sale !== null && $sale !== '' && is_numeric( $sale ) && (float) $sale > 0 && (float) $sale < (float) $regular ) {
				$batches[ $idx ]['sale'] = (string) (float) $sale;
			} else {
				unset( $batches[ $idx ]['sale'] );
			}
		} elseif ( $same_price ) {
			return $batches;
		}
		$batches[ $idx ]['price'] = (string) $regular;
		return $batches;
	}

	/**
	 * بند JOIN/ORDER BY برای سورت تاریخ انقضای فعال.
	 * محصولات بدون تاریخ انتهای لیست می‌مانند.
	 *
	 * @param string $join
	 * @param string $orderby
	 * @param string $posts_table
	 * @param string $postmeta_table
	 * @param string $order ASC|DESC
	 * @return array{0:string,1:string}
	 */
	public static function expiry_order_clauses( $join, $orderby, $posts_table, $postmeta_table, $order = 'ASC' ) {
		$join    = (string) $join;
		$orderby = (string) $orderby;
		if ( false !== strpos( $join, 'wbe_exp' ) ) {
			return array( $join, $orderby );
		}
		$order = ( 'DESC' === strtoupper( (string) $order ) ) ? 'DESC' : 'ASC';
		$join .= " LEFT JOIN {$postmeta_table} AS wbe_exp ON (wbe_exp.post_id = {$posts_table}.ID AND wbe_exp.meta_key = '_wbe_active_expiry') ";
		// والد متغیر متای انقضا ندارد — نزدیک‌ترین انقضای تنوع‌ها را هم ببین.
		$child_min = "(SELECT MIN(wbe_cpm.meta_value) FROM {$postmeta_table} wbe_cpm INNER JOIN {$posts_table} wbe_cvar ON wbe_cvar.ID = wbe_cpm.post_id WHERE wbe_cvar.post_parent = {$posts_table}.ID AND wbe_cvar.post_type = 'product_variation' AND wbe_cpm.meta_key = '_wbe_active_expiry' AND wbe_cpm.meta_value <> '')";
		$exp_val   = "COALESCE(NULLIF(wbe_exp.meta_value, ''), {$child_min})";
		$sql       = " CASE WHEN {$exp_val} IS NULL THEN 1 ELSE 0 END ASC, {$exp_val} {$order}, {$posts_table}.ID ASC ";
		return array( $join, $sql );
	}

	/**
	 * سطح هشدار بر اساس روز مانده تا انقضا.
	 * soon ≈ یک هفته، month ≈ یک ماه، two_months ≈ دو ماه.
	 *
	 * @param int|null $days
	 * @return string soon|month|two_months|expired|''
	 */
	public static function urgency( $days, $soon = 7, $month = 30, $two = 60 ) {
		if ( null === $days || $days === '' ) {
			return '';
		}
		$days  = (int) $days;
		$soon  = max( 0, (int) $soon );
		$month = max( $soon, (int) $month );
		$two   = max( $month, (int) $two );
		if ( $days < 0 ) {
			return 'expired';
		}
		if ( $days <= $soon ) {
			return 'soon';
		}
		if ( $days <= $month ) {
			return 'month';
		}
		if ( $days <= $two ) {
			return 'two_months';
		}
		return '';
	}

	public static function match_point( $days, array $points ) {
		if ( null === $days || $days === '' ) {
			return null;
		}
		$days = (int) $days;
		if ( $days < 0 ) {
			return 'expired';
		}
		$points = self::clean_points( $points );
		foreach ( $points as $point ) {
			if ( $days <= $point ) {
				return (int) $point;
			}
		}
		return null;
	}

	public static function clean_points( $points ) {
		$out = array();
		if ( ! is_array( $points ) ) {
			$points = array( $points );
		}
		foreach ( $points as $p ) {
			if ( class_exists( 'WBE_Jalali' ) ) {
				$raw = trim( WBE_Jalali::fa_to_en( $p ) );
			} else {
				$raw = trim( (string) $p );
			}
			$raw = str_replace( array( ',', '٬', '،', ' ' ), '', $raw );
			if ( $raw === '' || ! is_numeric( $raw ) ) {
				continue;
			}
			$n = (int) $raw;
			if ( $n >= 0 && $n <= 3650 ) {
				$out[] = $n;
			}
		}
		$out = array_values( array_unique( $out ) );
		sort( $out, SORT_NUMERIC );
		return $out;
	}

	public static function normalize_phone( $raw ) {
		$digits = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::fa_to_en( $raw ) : (string) $raw;
		$digits = preg_replace( '/\D+/', '', $digits );
		if ( strlen( $digits ) === 12 && 0 === strpos( $digits, '98' ) ) {
			$digits = '0' . substr( $digits, 2 );
		}
		if ( strlen( $digits ) === 10 && 0 === strpos( $digits, '9' ) ) {
			$digits = '0' . $digits;
		}
		return preg_match( '/^09\d{9}$/', $digits ) ? $digits : '';
	}

	/**
	 * مبلغ آزاد (ارقام فارسی، جداکننده هزارگان) → float یا null اگر خالی/نامعتبر.
	 * صفر معتبر است و با خالی فرق دارد.
	 *
	 * @param mixed $raw
	 * @return float|null
	 */
	public static function parse_amount( $raw ) {
		if ( null === $raw ) {
			return null;
		}
		$raw = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::fa_to_en( $raw ) : (string) $raw;
		$raw = trim( str_replace( array( ',', '٬', '،', ' ' ), '', $raw ) );
		if ( '' === $raw || ! is_numeric( $raw ) ) {
			return null;
		}
		return (float) $raw;
	}

	/**
	 * تغییر مبلغ. حالت‌ها: set, inc, dec, inc_pct, dec_pct.
	 *
	 * @param float|string $current مبلغ فعلی.
	 * @param string       $mode    حالت تغییر.
	 * @param mixed        $value   مقدار جدید یا اختلاف.
	 * @return float
	 */
	public static function change_amount( $current, $mode, $value ) {
		$current = (float) $current;
		$value   = (float) $value;
		switch ( $mode ) {
			case 'set':
				$out = $value;
				break;
			case 'inc':
				$out = $current + $value;
				break;
			case 'dec':
				$out = $current - $value;
				break;
			case 'inc_pct':
				$out = $current * ( 1 + ( $value / 100 ) );
				break;
			case 'dec_pct':
				$out = $current * ( 1 - ( $value / 100 ) );
				break;
			default:
				return max( 0, $current );
		}
		if ( $out < 0 ) {
			$out = 0;
		}
		return round( $out, 2 );
	}

	/**
	 * گرد کردن مبلغ بعد از تغییر درصدی.
	 *
	 * @param float  $amount
	 * @param string $mode   none|round|ceil|floor
	 * @return float
	 */
	public static function round_money( $amount, $mode ) {
		$amount = (float) $amount;
		switch ( $mode ) {
			case 'ceil':
				return (float) ceil( $amount );
			case 'floor':
				return (float) floor( $amount );
			case 'round':
				return (float) round( $amount );
			default:
				return round( $amount, 2 );
		}
	}

	/**
	 * آیا $ops تغییری روی قیمت/تخفیف دارد؟
	 *
	 * @param array $ops
	 * @return bool
	 */
	public static function has_price_ops( array $ops ) {
		if ( ! empty( $ops['clear_sale'] ) ) {
			return true;
		}
		if ( ! empty( $ops['regular_mode'] ) && 'none' !== $ops['regular_mode'] && array_key_exists( 'regular_value', $ops ) && null !== $ops['regular_value'] && '' !== $ops['regular_value'] ) {
			return true;
		}
		if ( ! empty( $ops['sale_mode'] ) && 'none' !== $ops['sale_mode'] && array_key_exists( 'sale_value', $ops ) && null !== $ops['sale_value'] && '' !== $ops['sale_value'] ) {
			return true;
		}
		if ( array_key_exists( 'discount', $ops ) && null !== $ops['discount'] && '' !== $ops['discount'] ) {
			return true;
		}
		return false;
	}

	/**
	 * قیمت، موجودی یا انقضای بچ فعال.
	 *
	 * @param array $ops
	 * @return bool
	 */
	public static function has_batch_ops( array $ops ) {
		if ( self::has_price_ops( $ops ) ) {
			return true;
		}
		if ( array_key_exists( 'stock', $ops ) && null !== $ops['stock'] && '' !== $ops['stock'] ) {
			return true;
		}
		if ( array_key_exists( 'reserved', $ops ) && null !== $ops['reserved'] && '' !== $ops['reserved'] ) {
			return true;
		}
		if ( array_key_exists( 'res_price', $ops ) || array_key_exists( 'res_discount', $ops )
			|| array_key_exists( 'res_stock', $ops ) || ! empty( $ops['res_expiry'] ) ) {
			return true;
		}
		if ( array_key_exists( 'reserves', $ops ) && is_array( $ops['reserves'] ) ) {
			return true;
		}
		if ( ! empty( $ops['expiry'] ) ) {
			return true;
		}
		return ! empty( $ops['add_batch'] );
	}

	/**
	 * اعمال عملیات گروهی فقط روی بچ فعال. رزرو دست نمی‌خورد مگر reserved ست شود.
	 *
	 * کلیدهای $ops:
	 *   regular_mode / regular_value
	 *   sale_mode / sale_value   (مبلغ بعد از تخفیف / جشنواره)
	 *   discount                 (درصد؛ اگر sale_mode خالی باشد)
	 *   clear_sale               (پاک کردن تخفیف)
	 *   reserved                 (جمع موجودی رزرو روی بچ‌های غیر فعال)
	 *   add_batch                (افزودن بچ رزرو: price/stock/expiry/discount/sale)
	 * اگر هم مبلغ جشنواره و هم درصد بیاید، مبلغ جشنواره اولویت دارد و مبلغ دقیق ذخیره می‌شود.
	 *
	 * @param array  $batches بچ‌ها.
	 * @param array  $ops     عملیات.
	 * @param string $today   Y-m-d.
	 * @return array
	 */
	public static function apply_bulk_to_active( array $batches, array $ops, $today ) {
		if ( array_key_exists( 'reserved', $ops ) && null !== $ops['reserved'] && '' !== $ops['reserved'] ) {
			$batches = self::set_reserved_stock( $batches, (int) $ops['reserved'], $today );
		}

		if ( array_key_exists( 'reserves', $ops ) && is_array( $ops['reserves'] ) ) {
			$cal     = isset( $ops['calendar'] ) ? (string) $ops['calendar'] : 'gregorian';
			$batches = self::replace_reserve_batches( $batches, $ops['reserves'], $today, $cal );
		} else {
			$batches = self::apply_bulk_to_reserve( $batches, $ops, $today );
		}

		if ( ! empty( $ops['add_batch'] ) && is_array( $ops['add_batch'] ) ) {
			$cal     = isset( $ops['calendar'] ) ? (string) $ops['calendar'] : 'gregorian';
			$batches = self::append_batch( $batches, $ops['add_batch'], $cal );
		}

		if ( empty( $batches ) || ! self::has_batch_ops( $ops ) ) {
			return $batches;
		}
		$has_res_ops = array_key_exists( 'res_price', $ops ) || array_key_exists( 'res_discount', $ops )
			|| array_key_exists( 'res_stock', $ops ) || ! empty( $ops['res_expiry'] )
			|| ( array_key_exists( 'reserves', $ops ) && is_array( $ops['reserves'] ) )
			|| ( array_key_exists( 'reserved', $ops ) && null !== $ops['reserved'] && '' !== $ops['reserved'] );
		// فقط افزودن بچ / تنظیم رزرو، بدون تغییر بچ فعال.
		$only_extra = ! empty( $ops['add_batch'] ) || $has_res_ops;
		if ( $only_extra && ! self::has_price_ops( $ops )
			&& ! ( array_key_exists( 'stock', $ops ) && null !== $ops['stock'] && '' !== $ops['stock'] )
			&& empty( $ops['expiry'] ) ) {
			return $batches;
		}

		$i = self::active_index( $batches, $today );
		if ( null === $i ) {
			return $batches;
		}

		$b       = $batches[ $i ];
		$regular = isset( $b['price'] ) ? (float) $b['price'] : 0;
		$round   = isset( $ops['round'] ) ? (string) $ops['round'] : '';

		if ( ! empty( $ops['regular_mode'] ) && 'none' !== $ops['regular_mode'] && array_key_exists( 'regular_value', $ops ) && null !== $ops['regular_value'] && '' !== $ops['regular_value'] ) {
			$regular    = self::change_amount( $regular, $ops['regular_mode'], $ops['regular_value'] );
			$regular    = self::round_money( $regular, $round );
			$b['price'] = (string) $regular;
		}

		if ( ! empty( $ops['clear_sale'] ) ) {
			$b['discount'] = 0;
			unset( $b['sale'] );
		} elseif ( ! empty( $ops['sale_mode'] ) && 'none' !== $ops['sale_mode'] && array_key_exists( 'sale_value', $ops ) && null !== $ops['sale_value'] && '' !== $ops['sale_value'] ) {
			$current_sale = self::effective_sale( $b );
			$new_sale     = self::round_money( self::change_amount( $current_sale, $ops['sale_mode'], $ops['sale_value'] ), $round );
			if ( $new_sale >= $regular ) {
				$b['discount'] = 0;
				unset( $b['sale'] );
			} else {
				$b['sale']     = (string) $new_sale;
				$b['discount'] = self::discount_from_prices( $regular, $new_sale );
			}
		} elseif ( array_key_exists( 'discount', $ops ) && null !== $ops['discount'] && '' !== $ops['discount'] ) {
			$b['discount'] = max( 0, min( 100, (int) round( (float) $ops['discount'] ) ) );
			unset( $b['sale'] ); // درصد، مبلغ جشنواره را از نو حساب می‌کند.
		}

		if ( array_key_exists( 'stock', $ops ) && null !== $ops['stock'] && '' !== $ops['stock'] ) {
			$sm         = ! empty( $ops['stock_mode'] ) ? (string) $ops['stock_mode'] : 'set';
			$b['stock'] = (int) max( 0, self::change_amount( isset( $b['stock'] ) ? $b['stock'] : 0, $sm, $ops['stock'] ) );
		}

		if ( ! empty( $ops['expiry'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $ops['expiry'] ) ) {
			$b['expiry'] = (string) $ops['expiry'];
		}

		$batches[ $i ] = $b;
		return $batches;
	}

	/**
	 * تغییر قیمت/موجودی محصول بدون بچ (فقط متای ووکامرس).
	 *
	 * @param float|string      $regular
	 * @param float|string|null $sale
	 * @param int|string        $stock
	 * @param array             $ops
	 * @return array{regular:string,sale:string,stock:int,discount:int}
	 */
	public static function apply_plain_state( $regular, $sale, $stock, array $ops ) {
		$regular  = (float) $regular;
		$has_sale = ( '' !== $sale && null !== $sale && is_numeric( $sale ) );
		$sale_amt = $has_sale ? (float) $sale : $regular;
		$stock    = (int) $stock;
		$round    = isset( $ops['round'] ) ? (string) $ops['round'] : '';

		if ( ! empty( $ops['regular_mode'] ) && 'none' !== $ops['regular_mode'] && array_key_exists( 'regular_value', $ops ) && null !== $ops['regular_value'] && '' !== $ops['regular_value'] ) {
			$regular = self::round_money( self::change_amount( $regular, $ops['regular_mode'], $ops['regular_value'] ), $round );
		}

		if ( ! empty( $ops['clear_sale'] ) ) {
			$has_sale = false;
			$sale_amt = $regular;
		} elseif ( ! empty( $ops['sale_mode'] ) && 'none' !== $ops['sale_mode'] && array_key_exists( 'sale_value', $ops ) && null !== $ops['sale_value'] && '' !== $ops['sale_value'] ) {
			$base     = $has_sale ? $sale_amt : $regular;
			$sale_amt = self::round_money( self::change_amount( $base, $ops['sale_mode'], $ops['sale_value'] ), $round );
			$has_sale = true;
		} elseif ( array_key_exists( 'discount', $ops ) && null !== $ops['discount'] && '' !== $ops['discount'] ) {
			$sale_amt = self::sale_price( $regular, $ops['discount'] );
			$has_sale = ( (float) $ops['discount'] > 0 );
		}

		if ( array_key_exists( 'stock', $ops ) && null !== $ops['stock'] && '' !== $ops['stock'] ) {
			$sm    = ! empty( $ops['stock_mode'] ) ? (string) $ops['stock_mode'] : 'set';
			$stock = (int) max( 0, self::change_amount( $stock, $sm, $ops['stock'] ) );
		}

		if ( ! $has_sale || $sale_amt >= $regular ) {
			$discount = 0;
			$sale_out = '';
		} else {
			$discount = self::discount_from_prices( $regular, $sale_amt );
			$sale_out = $discount > 0 ? (string) $sale_amt : '';
		}

		return array(
			'regular'  => (string) $regular,
			'sale'     => $sale_out,
			'stock'    => $stock,
			'discount' => $discount,
		);
	}

	/**
	 * یک ردیف جدول گروهی از دادهٔ خام دیتابیس.
	 *
	 * @param int         $id
	 * @param string      $title
	 * @param string      $sku
	 * @param array       $batches
	 * @param string      $calendar
	 * @param mixed       $sale_from
	 * @param mixed       $sale_to
	 * @param string      $today
	 * @param array       $wc     fallback ووکامرس وقتی بچی نیست.
	 * @return array
	 */
	public static function bulk_row_from_record( $id, $title, $sku, array $batches, $calendar, $sale_from, $sale_to, $today, $wc = array() ) {
		$idx      = self::active_index( $batches, $today );
		$active   = ( null !== $idx && isset( $batches[ $idx ] ) ) ? $batches[ $idx ] : null;
		$regular  = $active && isset( $active['price'] ) ? (string) $active['price'] : '';
		$discount = $active ? self::discount_of( $active ) : 0;
		$sale     = $active ? (string) self::effective_sale( $active ) : '';
		$stock    = $active ? (int) $active['stock'] : '';
		$reserved = self::reserved_stock( $batches, $today );
		$expiry   = ( $active && ! empty( $active['expiry'] ) ) ? (string) $active['expiry'] : '';

		$ridx      = self::primary_reserve_index( $batches, $today );
		$reserve   = ( null !== $ridx && isset( $batches[ $ridx ] ) ) ? $batches[ $ridx ] : null;
		$res_price = $reserve && isset( $reserve['price'] ) ? (string) $reserve['price'] : '';
		$res_disc  = $reserve ? self::discount_of( $reserve ) : '';
		$res_stock = $reserve ? (int) $reserve['stock'] : '';
		$res_exp   = ( $reserve && ! empty( $reserve['expiry'] ) ) ? (string) $reserve['expiry'] : '';

		$fmt = function ( $ymd ) use ( $calendar ) {
			if ( ! $ymd || ! class_exists( 'WBE_Jalali' ) ) {
				return '';
			}
			return WBE_Jalali::format_ymd( $ymd, $calendar, false );
		};

		$reserves_out = array();
		foreach ( self::reserve_batches( $batches, $today ) as $rb ) {
			$disc = self::discount_of( $rb );
			$exp  = isset( $rb['expiry'] ) ? (string) $rb['expiry'] : '';
			$reserves_out[] = array(
				'id'        => isset( $rb['id'] ) ? (string) $rb['id'] : '',
				'price'     => isset( $rb['price'] ) ? (string) $rb['price'] : '',
				'discount'  => $disc > 0 ? (int) $disc : '',
				'stock'     => isset( $rb['stock'] ) ? (int) $rb['stock'] : 0,
				'expiry'    => $exp,
				'expiry_fa' => $fmt( $exp ),
			);
		}

		if ( ! $active ) {
			$regular  = isset( $wc['regular'] ) ? (string) $wc['regular'] : '';
			$wc_sale  = isset( $wc['sale'] ) ? $wc['sale'] : '';
			$discount = self::discount_from_prices( $regular, $wc_sale );
			$sale     = ( '' !== $wc_sale && null !== $wc_sale ) ? (string) $wc_sale : $regular;
			$stock    = isset( $wc['stock'] ) && '' !== $wc['stock'] && null !== $wc['stock'] ? (int) $wc['stock'] : '';
		}
		$from = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::datetime_to_ymd( $sale_from ) : '';
		$to   = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::datetime_to_ymd( $sale_to ) : '';
		return array(
			'id'             => (int) $id,
			'name'           => (string) $title,
			'sku'            => (string) $sku,
			'status'         => isset( $wc['status'] ) ? (string) $wc['status'] : 'publish',
			'regular'        => $regular,
			'discount'       => $discount,
			'sale'           => $sale,
			'stock'          => $stock,
			'reserved'       => $reserved,
			'res_price'      => $res_price,
			'res_discount'   => ( '' === $res_disc || null === $res_disc ) ? '' : (int) $res_disc,
			'res_stock'      => $res_stock,
			'res_expiry'     => $res_exp,
			'res_expiry_fa'  => $fmt( $res_exp ),
			'reserves'       => $reserves_out,
			'from'           => $from,
			'to'             => $to,
			'from_fa'        => $fmt( $from ),
			'to_fa'          => $fmt( $to ),
			'expiry'         => $expiry,
			'expiry_fa'      => $fmt( $expiry ),
			'has_active'     => (bool) $active,
			'has_reserve'    => ! empty( $reserves_out ),
			'has_batches'    => ! empty( $batches ),
			'brand'          => isset( $wc['brand'] ) ? (string) $wc['brand'] : '',
			'is_variation'   => ! empty( $wc['is_variation'] ),
			'parent_id'      => isset( $wc['parent_id'] ) ? (int) $wc['parent_id'] : 0,
		);
	}

	/**
	 * شناسه‌ای که موجودی/بچ سفارش روی آن کم می‌شود.
	 *
	 * @param int $product_id
	 * @param int $variation_id
	 * @return int
	 */
	public static function order_item_stock_id( $product_id, $variation_id = 0 ) {
		$variation_id = (int) $variation_id;
		$product_id   = (int) $product_id;
		return $variation_id > 0 ? $variation_id : $product_id;
	}

	/**
	 * عنوان ردیف گروهی برای تنوع.
	 *
	 * @param string $parent_title
	 * @param string $attributes_label
	 * @return string
	 */
	public static function variation_row_title( $parent_title, $attributes_label = '' ) {
		$parent_title      = trim( (string) $parent_title );
		$attributes_label  = trim( (string) $attributes_label );
		if ( '' === $attributes_label ) {
			return $parent_title;
		}
		if ( '' === $parent_title ) {
			return $attributes_label;
		}
		return $parent_title . ' — ' . $attributes_label;
	}

	/**
	 * آیا این نوع محصول خودش قیمت/موجودی دارد؟ (نه والد متغیر)
	 *
	 * @param string $type
	 * @return bool
	 */
	public static function type_owns_stock( $type ) {
		$type = (string) $type;
		return 'variable' !== $type;
	}

	/**
	 * ردیف‌های SQL را یکتا کن — JOIN ترم‌ها/متا نباید محصول را تکرار کند.
	 *
	 * @param array<int,object> $records
	 * @return array<int,object>
	 */
	public static function unique_sql_records_by_id( array $records ) {
		$out = array();
		foreach ( $records as $rec ) {
			if ( ! is_object( $rec ) || ! isset( $rec->ID ) ) {
				continue;
			}
			$id = (int) $rec->ID;
			if ( $id <= 0 ) {
				continue;
			}
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = $rec;
				continue;
			}
			$have = isset( $out[ $id ]->product_type ) ? (string) $out[ $id ]->product_type : '';
			$next = isset( $rec->product_type ) ? (string) $rec->product_type : '';
			if ( '' === $have && '' !== $next ) {
				$out[ $id ] = $rec;
			}
		}
		return array_values( $out );
	}

	/**
	 * ردیف‌های جدول گروهی را بر اساس شناسه یکتا کن.
	 *
	 * @param array<int,array> $rows
	 * @return array<int,array>
	 */
	/**
	 * ردیف‌های فرم ویرایش تکی: بچ فعال + همهٔ رزروها.
	 *
	 * @param array $active
	 * @param array $reserve
	 * @return array<int,array>
	 */
	public static function merge_active_and_reserve_rows( $active, $reserve ) {
		$rows = array();
		if ( is_array( $active ) && $active ) {
			$rows[] = $active;
		}
		if ( is_array( $reserve ) ) {
			foreach ( $reserve as $row ) {
				if ( is_array( $row ) ) {
					$rows[] = $row;
				}
			}
		}
		return $rows;
	}

	/**
	 * دادهٔ POST تنوع: اول با شناسهٔ تنوع، بعد با ایندکس حلقه (فرم قدیمی).
	 *
	 * @param array $all
	 * @param int   $variation_id
	 * @param int   $loop
	 * @return array|null
	 */
	public static function posted_variation_data( $all, $variation_id, $loop = 0 ) {
		if ( ! is_array( $all ) ) {
			return null;
		}
		$variation_id = (int) $variation_id;
		$loop         = (int) $loop;
		$keys         = array();
		if ( $variation_id > 0 ) {
			$keys[] = $variation_id;
			$keys[] = (string) $variation_id;
		}
		$keys[] = $loop;
		$keys[] = (string) $loop;
		foreach ( $keys as $key ) {
			if ( isset( $all[ $key ] ) && is_array( $all[ $key ] ) ) {
				return $all[ $key ];
			}
		}
		return null;
	}

	/**
	 * آیا ردیف فرم شبیه تلاش برای ثبت بچ است؟ (حتی اگر تاریخ نامعتبر باشد)
	 *
	 * @param array $row
	 * @return bool
	 */
	public static function row_looks_like_batch_attempt( $row ) {
		if ( ! is_array( $row ) ) {
			return false;
		}
		$price = class_exists( 'WBE_Jalali' ) ? WBE_Jalali::number( isset( $row['price'] ) ? $row['price'] : 0 ) : (float) ( isset( $row['price'] ) ? $row['price'] : 0 );
		$stock = (int) ( class_exists( 'WBE_Jalali' ) ? WBE_Jalali::number( isset( $row['stock'] ) ? $row['stock'] : 0 ) : ( isset( $row['stock'] ) ? $row['stock'] : 0 ) );
		$exp   = isset( $row['expiry'] ) ? trim( (string) $row['expiry'] ) : '';
		return ( '' !== $exp || $price > 0 || $stock > 0 );
	}

	/**
	 * بچ‌های ارسالی فرم: آرایه برای ذخیره، null یعنی موجودی فعلی را نگه دار.
	 *
	 * @param array  $rows
	 * @param string $calendar
	 * @return array|null
	 */
	public static function decide_posted_batches( $rows, $calendar = 'gregorian' ) {
		$rows  = is_array( $rows ) ? $rows : array();
		$clean = self::sanitize_batches( $rows, $calendar );
		if ( $clean ) {
			return $clean;
		}
		foreach ( $rows as $row ) {
			if ( self::row_looks_like_batch_attempt( $row ) ) {
				return null;
			}
		}
		return array();
	}

	/**
	 * شناسه تنوع‌های هم‌والد، بدون مبدأ.
	 *
	 * @param int   $from_id
	 * @param array $ids
	 * @return array<int,int>
	 */
	public static function sibling_ids( $from_id, $ids ) {
		$from_id = (int) $from_id;
		$out     = array();
		if ( ! is_array( $ids ) ) {
			return $out;
		}
		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( $id <= 0 || $id === $from_id || isset( $out[ $id ] ) ) {
				continue;
			}
			$out[ $id ] = $id;
		}
		return array_values( $out );
	}

	/**
	 * متن اعلان وقتی فرم انقضا نامعتبر است و بچ قبلی نگه داشته می‌شود.
	 *
	 * @return string
	 */
	public static function incomplete_batches_notice() {
		return 'تاریخ انقضا نامعتبر بود و ذخیره نشد. بچ قبلی همین‌طور ماند. تاریخ را از تقویم کنار فیلد انتخاب کنید.';
	}

	public static function unique_bulk_rows( array $rows ) {
		$out = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['id'] ) ) {
				continue;
			}
			$id = (int) $row['id'];
			if ( $id <= 0 || isset( $out[ $id ] ) ) {
				continue;
			}
			$out[ $id ] = $row;
		}
		return array_values( $out );
	}
}
