<?php
defined( 'ABSPATH' ) || exit;
$edition = ( defined( 'WBE_EDITION' ) && 'pro' === WBE_EDITION ) ? 'پرو' : 'رایگان';
$tg      = class_exists( 'WBE_Support' ) ? WBE_Support::telegram_handle() : 'HAJITODAY';
$tg_url  = class_exists( 'WBE_Support' ) ? WBE_Support::telegram_chat_url() : 'https://t.me/HAJITODAY';
?>
<div class="wrap wbe-wrap wbe-help-wrap" dir="rtl">
	<h1>راهنمای انقضای کالا <span class="wbe-ver"><?php echo esc_html( WBE_VERSION . ' — ' . $edition ); ?></span></h1>
	<p class="wbe-sub">سازنده: <a href="https://webakery.ir" target="_blank" rel="noopener">webakery.ir</a> — اگر باگی دیدید با دکمهٔ گزارش باگ برای <a href="<?php echo esc_url( $tg_url ); ?>" target="_blank" rel="noopener">@<?php echo esc_html( $tg ); ?></a> بفرستید.</p>
	<p class="wbe-sub">نسخه رایگان و پرو <strong>امکانات یکسان</strong> دارند. نسخه پرو فقط لایسنس و به‌روزرسانی از webakery.ir دارد.</p>

	<p>
		<button type="button" class="button button-primary wbe-bug-open">گزارش باگ با اسکرین و توضیح</button>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=webakery-expiry-bulk' ) ); ?>">ویرایش گروهی</a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=webakery-expiry-settings' ) ); ?>">تنظیمات</a>
	</p>

	<div class="wbe-help-grid">
		<section class="wbe-help-card">
			<h2>۱. ایده اصلی</h2>
			<p>برای هر محصول (یا هر تنوع) چند <strong>بچ</strong> می‌گذارید: قیمت، تخفیف، موجودی و تاریخ انقضا.</p>
			<ul>
				<li><strong>موجودی فعال (بچ ۱):</strong> هر عددی که بگذارید روی موجودی ووکامرس SET می‌شود و در فروشگاه فروخته می‌شود.</li>
				<li><strong>موجودی رزرو (بچ ۲، ۳، …):</strong> وقتی بچ فعال تمام یا منقضی شد، موجودی بچ بعدی جایگزین موجودی ووکامرس می‌شود و فروش از همان ادامه می‌یابد.</li>
			</ul>
		</section>

		<section class="wbe-help-card">
			<h2>۲. ویرایش تکی محصول</h2>
			<p>ووکامرس ← محصولات ← ویرایش. باکس «موجودی فعال» و «موجودی رزرو» کنار قیمت است.</p>
			<ul>
				<li>قیمت، تخفیف، جشنواره، موجودی و انقضا را اینجا عوض کنید.</li>
				<li>همان باکس در <strong>ویرایش سریع</strong> لیست محصولات هم هست.</li>
				<li>نام، SKU و وضعیت را از همین صفحه ووکامرس یا از <strong>ویرایش گروهی</strong> عوض کنید.</li>
				<li>محصول متغیر: برای <strong>هر تنوع</strong> جداگانه بچ بگذارید (نه روی والد). موجودی هر تنوع از موجودی ووکامرس همان تنوع خوانده می‌شود.</li>
			</ul>
		</section>

		<section class="wbe-help-card">
			<h2>۳. ویرایش گروهی (و رفع کندی)</h2>
			<p>بدون انتخاب <strong>برند</strong> هیچ محصولی لود نمی‌شود تا صفحه سنگین نشود.</p>
			<ol>
				<li>برند را انتخاب کنید و «اعمال فیلتر» را بزنید.</li>
				<li>در صورت نیاز دسته، وضعیت یا «دارای انقضا» را هم فیلتر کنید.</li>
				<li>برای دیدن رزرو، سوییچ «نمایش و ویرایش موجودی رزرو» را روشن کنید.</li>
				<li>سلول را عوض کنید و «ذخیره سلول‌های تغییرکرده» را بزنید، یا نوار بالا را پر کنید و روی انتخاب‌شده‌ها اعمال کنید.</li>
			</ol>
			<p class="description">ذخیره تکه‌تکه انجام می‌شود تا تایم‌اوت نگیرد. محصول متغیر در جدول به ردیف‌های تنوع شکسته می‌شود. ستون موجودی فعال از ووکامرس می‌آید. ستون «کل موجودی» جمع موجودی فعال و رزرو است. مبالغ نوار بالا به‌صورت پیش‌فرض تا ۲ رقم اعشار گرد می‌شوند.</p>
		</section>

		<section class="wbe-help-card">
			<h2>۴. فروشگاه</h2>
			<ul>
				<li>تاریخ انقضا کنار محصول (از تنظیمات).</li>
				<li>تایمر «مانده تا پایان کمپین» اگر تخفیف و بازه جشنواره فعال باشد.</li>
				<li>محصول متغیر: بعد از انتخاب تنوع، انقضای همان تنوع نشان داده می‌شود.</li>
				<li>شورت‌کد: <code>[webakery_expiry]</code> — روی محصول متغیر اگر فرم انتخاب تنوع نباشد، نزدیک‌ترین انقضا نشان داده می‌شود.</li>
			</ul>
		</section>

		<section class="wbe-help-card">
			<h2>۵. تقویم تاریخ و کپی تنوع</h2>
			<ul>
				<li>روی فیلد تاریخ کلیک کنید؛ تقویم شمسی یا میلادی باز می‌شود.</li>
				<li>اگر تاریخ نامعتبر ذخیره شود، بچ قبلی پاک نمی‌شود و یک اعلان زرد می‌بینید.</li>
				<li>روی هر تنوع دکمهٔ <strong>کپی بچ‌ها به همه تنوع‌ها</strong> همان قیمت، موجودی و انقضا را روی بقیه تنوع‌ها می‌گذارد.</li>
			</ul>
		</section>

		<section class="wbe-help-card">
			<h2>۶. گزارش باگ</h2>
			<p>اگر چیزی کند، تکراری یا غلط بود:</p>
			<ol>
				<li>دکمهٔ شناور «گزارش باگ» یا دکمهٔ بالای این صفحه را بزنید.</li>
				<li>توضیح بدهید چه کار کردید و چه دیدید.</li>
				<li>اسکرین همین صفحه را بگیرید یا فایل تصویر بچسبانید.</li>
				<li>ارسال، چت تلگرام <strong>@<?php echo esc_html( $tg ); ?></strong> را باز می‌کند؛ تصویر را همان‌جا پیوست کنید.</li>
			</ol>
		</section>
	</div>
</div>
