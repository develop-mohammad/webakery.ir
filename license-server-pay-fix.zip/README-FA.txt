رفع خطای پرداخت (۵۰۰)
======================

1) محتویات این ZIP را داخل پوشه license-server روی هاست Extract کن
   (جایگزین شدن pay/index.php و includes/LicenseManager.php و updates/webakery-chat-box.zip درست است)

2) این لینک را باز کن و متن را بخوان:
   https://webakery.ir/license-server/debug-boot.php

3) اگر خطای config.php بود:
   - فایل config.php را از بکاپ برگردان
   - یا طبق CONFIG-CHAT-PLANS.txt فقط بخش LS_PLANS را درست کن
   - کل config.php ریپو را جایگزین نکن (رمزها پاک می‌شود)

4) تست پرداخت:
   https://webakery.ir/license-server/pay/?plugin=webakery-chat

5) در پایان این دو فایل را حذف کن:
   debug-boot.php
   health.php
